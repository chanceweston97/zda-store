# Environment Variables Setup

## Quick Setup for zdacomm.com

Create a file named `.env.local` in the `frontend` directory with the following content:

```env
# WooCommerce Configuration
NEXT_PUBLIC_WC_API_URL=https://zdacomm.com/wp-json/wc/v3
NEXT_PUBLIC_WC_SITE_URL=https://zdacomm.com
NEXT_PUBLIC_WC_CONSUMER_KEY=ck_58b71c50e35173590e7a668eb91db3ddf12fffc7
NEXT_PUBLIC_WC_CONSUMER_SECRET=cs_a49a9ae2fef3937c80a75461abac3df9a14607a4

# WordPress CMS Configuration
NEXT_PUBLIC_CMS_URL=https://cms.zdacomm.com

# Contact Form 7 Configuration
# Get Form IDs from WordPress Admin → Contact → Contact Forms
# The Form ID is shown in the shortcode: [contact-form-7 id="FORM_ID" title="..."]
CONTACT_FORM_7_NEWSLETTER_ID=04c4294
CONTACT_FORM_7_CONTACT_ID=3879106
CONTACT_FORM_7_QUOTE_ID=90b787e
```

## Steps

1. Navigate to the `frontend` directory
2. Create a new file named `.env.local`
3. Copy the content above into the file
4. **Get Contact Form 7 Form IDs:**
   - Log in to WordPress Admin at `https://cms.zdacomm.com/wp-admin`
   - Go to **Contact → Contact Forms**
   - Click on each form (Newsletter, Contact, Quote Request)
   - The Form ID is shown in the form settings or in the URL (e.g., `post.php?post=12345&action=edit`)
   - Replace `your_contact_form_id_here` and `your_quote_form_id_here` with the actual Form IDs
5. Save the file
6. Restart your Next.js development server

## Contact Form 7 Form Setup

### Newsletter Form
- Form ID: `04c4294`
- Required field: `your-email`

### Contact Form
- Form ID: `3879106`
- Required fields in your Contact Form 7 form:
  - `first-name` (First Name)
  - `last-name` (Last Name)
  - `your-email` (Email)
  - `your-tel` (Phone Number)
  - `your-subject` (Company Name)
  - `your-message` (Message - optional)

### Quote Request Form
- Form ID: `90b787e`
- Required fields in your Contact Form 7 form:
  - `first-name` (First Name)
  - `last-name` (Last Name)
  - `your-email` (Email)
  - `your-tel` (Phone Number)
  - `your-product` (Product/Service of Interest)
  - `your-subject` (Company Name)
  - `your-message` (Message - optional)

### Important Notes for Contact Form 7

1. **Field Names**: The field names in your Contact Form 7 forms must match the field names used in the API routes:
   - Contact form: `first-name`, `last-name`, `your-email`, `your-tel`, `your-subject`, `your-message`
   - Quote form: `first-name`, `last-name`, `your-email`, `your-tel`, `your-product`, `your-subject`, `your-message`
   - Newsletter form: `your-email`

2. **If your Contact Form 7 uses different field names**, you'll need to update the API routes:
   - `frontend/src/app/api/contact/route.ts` - Update `formData.append()` calls
   - `frontend/src/app/api/quote-request/route.ts` - Update `formData.append()` calls

3. **Testing**: After setting up, test each form:
   - Newsletter: Subscribe with an email
   - Contact: Submit with all required fields
   - Quote Request: Submit with all required fields

4. **View Submissions**: All submissions are stored in WordPress Admin:
   - Go to **Contact → Flamingo** to view all form submissions
   - Emails are sent via WP Mail SMTP (Microsoft 365)

## Verification

After setting up the environment variables, you should see:
- The "Checkout with WooCommerce" button appears on the checkout page
- No errors in the console about missing WooCommerce configuration
- Forms submit successfully and redirect to `/mail-success`
- Submissions appear in WordPress Admin → Contact → Flamingo

## Important Notes

- `.env.local` is in `.gitignore` and won't be committed to git
- Never commit your API credentials to version control
- If you're using a different environment (staging, production), create separate `.env` files for each

