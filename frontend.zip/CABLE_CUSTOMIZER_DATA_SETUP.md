# Cable Customizer Data Setup Guide

## Overview
The cable customizer page uses local data stored in `frontend/src/lib/data/cable-customizer-data.ts`. This file contains all cable series, cable types, and connectors with their pricing information.

## What Data Do I Need?

You need to provide **3 types of data**:

### 1. Cable Series
Simple list of cable series (usually just "RG Series" and "LMR Series"):
```typescript
{
  id: "rg-series",
  _id: "rg-series",
  name: "RG Series",
  slug: "rg-series",
  image: null,
}
```

### 2. Cable Types
List of all cable types with their **price per foot** (in DOLLARS):
```typescript
{
  id: "rg-58",
  _id: "rg-58",
  name: "RG-58",
  slug: "rg-58",
  series: "rg-series",        // Which series it belongs to
  seriesName: "RG Series",     // Series display name
  pricePerFoot: 0.50,          // $0.50 per foot (in DOLLARS)
  image: null,                  // Image URL or null
  maxLength: null,              // Optional: max length in feet
  allowedConnectors: null,      // Optional: array of allowed connector slugs
}
```

### 3. Connectors
List of all connectors with **pricing per cable type** (in DOLLARS):
```typescript
{
  id: "n-male",
  _id: "n-male",
  name: "N Male",
  slug: "n-male",
  image: null,                  // Image URL or null
  pricing: [
    {
      cableTypeSlug: "rg-58",   // Which cable type (lowercase slug)
      cableTypeName: "RG-58",   // Cable type display name
      price: 5.00,               // $5.00 for this connector with RG-58 (in DOLLARS)
    },
    {
      cableTypeSlug: "lmr-400",
      cableTypeName: "LMR-400",
      price: 6.00,               // $6.00 for this connector with LMR-400
    },
    // ... more cable types
  ],
}
```

## Price Calculation Formula

The cable customizer uses this formula:
```
Total Price = ((Connector 1 Price + Cable Footage Cost + Connector 2 Price) × 1.35) × Quantity

Where:
- Cable Footage Cost = pricePerFoot × length (in feet)
- All prices are in DOLLARS
```

## How to Provide the Data

You can provide the data in any of these formats, and I'll convert it to the TypeScript format:

### Option 1: JSON Format
Provide a JSON file or JSON object with the following structure:
You can provide the data in JSON format, and I'll convert it to TypeScript. The JSON structure should be:

```json
{
  "cableSeries": [
    { "id": "rg-series", "_id": "rg-series", "name": "RG Series", "slug": "rg-series", "image": null }
  ],
  "cableTypes": [
    {
      "id": "rg-58",
      "_id": "rg-58",
      "name": "RG-58",
      "slug": "rg-58",
      "series": "rg-series",
      "seriesName": "RG Series",
      "pricePerFoot": 0.50,
      "image": null
    }
  ],
  "connectors": [
    {
      "id": "n-male",
      "_id": "n-male",
      "name": "N Male",
      "slug": "n-male",
      "image": null,
      "pricing": [
        {
          "cableTypeSlug": "rg-58",
          "cableTypeName": "RG-58",
          "price": 5.00
        }
      ]
    }
  ]
}
```

## Next Steps

1. **Provide the data** from your database in any format:
   - JSON file or object
   - SQL export
   - CSV/Excel file
   - Or paste the data directly

2. **I'll convert and update** `frontend/src/lib/data/cable-customizer-data.ts` with your data

3. **Test** the cable customizer page to ensure prices calculate correctly

## Database Query Examples

If you're extracting from a database, here's what you need:

**Cable Series:**
- id, name, slug

**Cable Types:**
- id, name, slug, series (slug), seriesName, pricePerFoot, image (optional), maxLength (optional)

**Connectors:**
- id, name, slug, image (optional)
- pricing: array of { cableTypeSlug, cableTypeName, price }

## Important Notes

- **All prices must be in DOLLARS** (not cents)
- **Cable type slugs** in connector pricing must match exactly (case-insensitive, but normalized to lowercase)
- **Series slugs** must match between cable types and series
- If a connector doesn't have pricing for a specific cable type, it won't be selectable for that cable type

## Questions?

If you're not sure about the data format or need help extracting it, let me know:
- Do you have access to your Medusa backend?
- Do you have the data in another format?
- Can you provide a sample of your cable types and connectors?

