// Hero Introduction Data
import { HeroIntroduction } from "../types";

export const heroIntroduction: HeroIntroduction = {
  id: "hero-intro-1",
  // Add your hero introduction content here
};

export default heroIntroduction;

