// Our Story Data
import { OurStory } from "../types";

export const ourStory: OurStory = {
  id: "our-story-1",
  // Add your content here
};

export default ourStory;

