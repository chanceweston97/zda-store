// Hero Banners Data
import { HeroBanner } from "../types";

export const heroBanners: HeroBanner[] = [
  // Add your hero banners here
];

export default heroBanners;

