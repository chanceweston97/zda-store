// FAQ Data
import { FAQ } from "../types";

export const faqs: FAQ[] = [
  // Add your FAQs here
];

export default faqs;

