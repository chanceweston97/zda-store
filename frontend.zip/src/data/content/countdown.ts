// Countdown Data
import { Countdown } from "../types";

export const countdown: Countdown = {
  id: "countdown-1",
  enabled: false,
  // Add your countdown data here
};

export default countdown;

