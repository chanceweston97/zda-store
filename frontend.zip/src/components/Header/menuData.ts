import { Menu } from "@/types/Menu";

export const menuData: Menu[] = [
  {
    id: 1,
    title: "Products",
    newTab: false,
    path: "/shop",
    submenu: [
      {
        id: 61,
        title: "Antennas",
        newTab: false,
        path: "/categories/antennas",
        submenu: [
          {
            id: 611,
            title: "Yagi Antennas",
            newTab: false,
            path: "/categories/yagi-antennas",
          },
          {
            id: 612,
            title: "Omni Antennas",
            newTab: false,
            path: "/categories/omni-antennas",
          },
          {
            id: 613,
            title: "Parabolic Antennas",
            newTab: false,
            path: "/categories/parabolic-antennas",
          },
        ],
      },
      {
        id: 62,
        title: "Cables",
        newTab: false,
        path: "/categories/cables",
      },
      {
        id: 64,
        title: "Connectors",
        newTab: false,
        path: "/categories/connectors",
      },
    
    
    ]
  },
  {
    id: 2,
    title: "Cable Customizer",
    newTab: false,
    path: "/cable-customizer",
  },
  {
    id: 3,
    title: "Request a Quote",
    newTab: false,
    path: "/request-a-quote",
  },
  {
    id: 3,
    title: "Our Story",
    newTab: false,
    path: "/our-story",
  },
  {
    id: 3,
    title: "Contact Us",
    newTab: false,
    path: "/contact",
  },
 
];
