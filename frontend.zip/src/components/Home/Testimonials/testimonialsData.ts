const testimonialsData = [
  {
    review: `Lorem ipsum dolor sit amet, adipiscing elit. Donec malesuada justo vitaeaugue suscipit beautiful vehicula`,
    authorName: 'Davis Dorwart',
    authorImg: '/images/users/user-01.jpg',
    authorRole: 'Serial Entrepreneur',
  },
  {
    review:
      'Lorem ipsum dolor sit amet, adipiscing elit. Donec malesuada justo vitaeaugue suscipit beautiful vehicula',
    authorName: 'Wilson Dias',
    authorImg: '/images/users/user-04.jpg',
    authorRole: 'Backend Developer',
  },
];

export default testimonialsData;
