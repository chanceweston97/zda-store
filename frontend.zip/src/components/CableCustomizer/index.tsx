// Re-export the client component
export { default } from "./CableCustomizerClient";
export { default as CableCustomizerClient } from "./CableCustomizerClient";
