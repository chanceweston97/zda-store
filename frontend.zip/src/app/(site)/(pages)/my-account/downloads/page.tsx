export default function Page() {
  return (
    <div className="xl:max-w-[770px] w-full bg-white rounded-xl shadow-1 py-9.5 px-4 sm:px-7.5 xl:px-10">
      <p>You don&apos;t have any download</p>
    </div>
  );
}
