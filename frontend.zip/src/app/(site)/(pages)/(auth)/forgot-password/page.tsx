import ForgotPassword from "@/components/Auth/ForgotPassword";
import React from "react";

const ForgotPasswordPage = () => {
  return (
    <main>
      <ForgotPassword />
    </main>
  );
};

export default ForgotPasswordPage;
