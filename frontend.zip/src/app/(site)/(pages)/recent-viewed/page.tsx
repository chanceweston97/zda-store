import RecentlyViewedItems from "@/components/ShopDetails/RecentlyViewed";
import React from "react";

export default function RecentViewedPag() {
  return (
    <div>
      <RecentlyViewedItems />
    </div>
  );
}
