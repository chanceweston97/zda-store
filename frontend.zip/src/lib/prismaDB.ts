// NOTE: Prisma has been removed from this project.
// This file exists only to prevent import errors.
// All Prisma-dependent functionality should be migrated to Medusa or removed.

export const prisma = null as any;

