# Deployment Checklist - Medusa Backend URL

## ⚠️ CRITICAL: Server Environment Variables

Your shop page will **FAIL** on the server if `NEXT_PUBLIC_MEDUSA_BACKEND_URL` is not set correctly.

## ✅ Step-by-Step Fix:

### 1. Check Your Frontend `.env.local` File

In `zda-sanity/.env.local`, you MUST have:

```env
NEXT_PUBLIC_MEDUSA_BACKEND_URL=http://18.224.229.214:9000
NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY=pk_a4a69691025b26fa326c9f30b87439a9272ed216aed7be982d500a7171c7b224
NEXT_PUBLIC_USE_MEDUSA=true
```

### 2. Verify Environment Variables Are Loaded

After setting `.env.local`, **rebuild** your Next.js app:

```bash
cd zda-sanity
yarn build
```

**IMPORTANT**: Next.js only reads `.env.local` at **build time**. You MUST rebuild after changing environment variables.

### 3. Check Server Logs

After deploying, check your server logs. You should see:

```
[ShopPage] Backend URL: http://18.224.229.214:9000
[MedusaClient] Fetching: http://18.224.229.214:9000/store/products?...
```

If you see:
```
[ShopPage] Backend URL: http://localhost:9000
```

**This means the environment variable is NOT set correctly!**

### 4. Common Issues:

#### Issue 1: Environment Variable Not Set
**Symptom**: Logs show `localhost:9000` or `not set`
**Fix**: 
- Check `.env.local` exists in `zda-sanity/` directory
- Verify `NEXT_PUBLIC_MEDUSA_BACKEND_URL` is set
- **Rebuild**: `yarn build`

#### Issue 2: Wrong Variable Name
**Symptom**: Variable not being read
**Fix**: 
- Must be `NEXT_PUBLIC_MEDUSA_BACKEND_URL` (with `NEXT_PUBLIC_` prefix)
- NOT just `MEDUSA_BACKEND_URL` (that won't work in browser)

#### Issue 3: Not Rebuilt After Changing .env
**Symptom**: Old value still being used
**Fix**: 
- **Always rebuild** after changing `.env.local`
- `yarn build` or `npm run build`

### 5. Production Server Setup

If you're using PM2 or similar:

```bash
# Set environment variables in PM2
pm2 start npm --name "zda-sanity" -- start -- --env production

# Or use ecosystem file
pm2 ecosystem
```

Create `ecosystem.config.js`:
```js
module.exports = {
  apps: [{
    name: 'zda-sanity',
    script: 'npm',
    args: 'start',
    env: {
      NODE_ENV: 'production',
      NEXT_PUBLIC_MEDUSA_BACKEND_URL: 'http://18.224.229.214:9000',
      NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY: 'pk_a4a69691025b26fa326c9f30b87439a9272ed216aed7be982d500a7171c7b224',
      NEXT_PUBLIC_USE_MEDUSA: 'true',
    }
  }]
};
```

### 6. Quick Test

After deployment, check the server logs for:

```
[ShopPage] ========================================
[ShopPage] Backend URL: http://18.224.229.214:9000  ← Should show server IP
[ShopPage] NODE_ENV: production
[ShopPage] ========================================
```

If it shows `localhost:9000`, the environment variable is NOT set correctly!

## 🔍 Debugging Commands

```bash
# Check if .env.local exists
ls -la zda-sanity/.env.local

# Check environment variables (after build)
cat zda-sanity/.next/server/app-paths-manifest.json | grep MEDUSA

# Check server logs
pm2 logs zda-sanity
# or
tail -f /var/log/your-app.log
```

## ✅ Success Indicators

When working correctly, you'll see in logs:
- ✅ `[ShopPage] Backend URL: http://18.224.229.214:9000`
- ✅ `[MedusaClient] Fetching: http://18.224.229.214:9000/store/products`
- ✅ `[ShopPage] Successfully fetched X products from Medusa backend`

## ❌ Failure Indicators

When NOT working, you'll see:
- ❌ `[ShopPage] Backend URL: http://localhost:9000`
- ❌ `[MedusaClient] ⚠️ WARNING: Backend URL is localhost in production!`
- ❌ `[ShopPage] ❌❌❌ CRITICAL ERROR: Using localhost in production!`

