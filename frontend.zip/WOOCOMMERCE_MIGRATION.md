# WooCommerce Migration Guide

This document outlines the migration from Medusa to WooCommerce Headless CMS.

## Overview

The project has been migrated from Medusa backend to WooCommerce/WordPress Headless CMS. The frontend UI remains unchanged, but the data layer now connects to WooCommerce via REST API.

## Environment Variables

### Remove (No longer needed)
- `NEXT_PUBLIC_MEDUSA_BACKEND_URL` 
- `NEXT_PUBLIC_MEDUSA_PUBLISHABLE_KEY`
- `MEDUSA_BACKEND_URL`
- `NEXT_PUBLIC_USE_MEDUSA`

### Add (Required for WooCommerce)
```env
# WooCommerce REST API Configuration
# ✅ Configured for zdacomm.com
NEXT_PUBLIC_WC_API_URL=https://zdacomm.com/wp-json/wc/v3
NEXT_PUBLIC_WC_SITE_URL=https://zdacomm.com
NEXT_PUBLIC_WC_CONSUMER_KEY=ck_58b71c50e35173590e7a668eb91db3ddf12fffc7
NEXT_PUBLIC_WC_CONSUMER_SECRET=cs_a49a9ae2fef3937c80a75461abac3df9a14607a4
```

**Note**: The `.env.local` file has been created in the `frontend` directory with these credentials.

### How to Get WooCommerce API Credentials

1. Log in to your WordPress admin panel
2. Go to **WooCommerce → Settings → Advanced → REST API**
3. Click **Add Key**
4. Set description (e.g., "Next.js Frontend")
5. Set user to an administrator
6. Set permissions to **Read/Write**
7. Click **Generate API Key**
8. Copy the **Consumer Key** and **Consumer Secret**

## Architecture Changes

### Cart Management
- **Client-side**: Cart is managed using `use-shopping-cart` library (unchanged)
- **Backend**: Cart items are synced to WooCommerce at checkout time
- **Session**: WooCommerce uses session-based carts (handled automatically)

### Checkout Flow
- **Headless Checkout (Implemented)**: Keep current checkout page, create orders via API
  - User stays on Next.js checkout page (no redirect)
  - User fills out checkout form as usual
  - On submit, order is created in WooCommerce via REST API
  - Payment is processed (Stripe or COD)
  - Order appears in WordPress admin
  - ✅ Same UI/UX as before
  - ✅ Full control over checkout experience
  - ✅ Orders created in WooCommerce backend

### Product Data
- Products are fetched from WooCommerce REST API
- Product IDs need to be mapped between systems
- Custom products (cables) are handled via meta_data

## File Structure

### New Files
- `/lib/woocommerce/client.ts` - WooCommerce API client
- `/lib/woocommerce/cart.ts` - Cart operations (server-side)
- `/lib/woocommerce/checkout.ts` - Checkout operations
- `/lib/woocommerce/config.ts` - Configuration
- `/lib/woocommerce/utils.ts` - Utility functions
- `/app/api/woocommerce/sync-cart/route.ts` - Cart sync API endpoint
- `/components/Checkout/WooCommerceCheckoutButton.tsx` - Checkout button

### Modified Files
- `/components/Checkout/CheckoutPaymentArea.tsx` - Added WooCommerce checkout option

### Ignored Files (Medusa - Keep for reference, but not used)
- `/lib/medusa/*` - Medusa integration (kept for reference)
- `/backend/*` - Medusa backend (can be removed or ignored)

## Migration Steps

1. ✅ Created WooCommerce API layer
2. ✅ Added WooCommerce checkout redirect
3. ✅ Updated checkout component
4. ⏳ Update environment variables
5. ⏳ Test cart and checkout flow
6. ⏳ Map product IDs between systems
7. ⏳ Remove/ignore Medusa backend

## Testing Checklist

- [ ] Add custom cable to cart
- [ ] Add another product to cart
- [ ] Cart persistence (refresh page)
- [ ] Click "Checkout with WooCommerce"
- [ ] Redirect to WordPress checkout
- [ ] Complete order in WordPress
- [ ] Verify order appears in WordPress admin

## Product ID Mapping

**Important**: You need to map your product IDs from the old system to WooCommerce product IDs.

Current cart items use `item.id` which may be from Sanity/Medusa. You need to:
1. Create products in WooCommerce
2. Map old product IDs to WooCommerce product IDs
3. Update `convertCartItemToWC()` in `/lib/woocommerce/utils.ts`

Example mapping:
```typescript
const PRODUCT_ID_MAP: Record<string, number> = {
  "old-product-id-1": 123, // WooCommerce product ID
  "old-product-id-2": 124,
  // ...
};
```

## Troubleshooting

### WooCommerce checkout button not showing
- Check that all WooCommerce environment variables are set
- Verify `isWooCommerceEnabled()` returns `true`
- Check browser console for errors

### Cart items not syncing
- WooCommerce REST API doesn't have a direct cart endpoint
- Consider creating a custom WordPress REST endpoint for cart management
- Or use session-based approach with WooCommerce session API

### Product IDs not matching
- Update `convertCartItemToWC()` function
- Create a product ID mapping table
- Ensure products exist in WooCommerce

## Next Steps

1. Set up WooCommerce on WordPress
2. Configure environment variables
3. Map product IDs
4. Test the full checkout flow
5. Remove Medusa backend (optional)

## Support

For issues or questions:
- Check WooCommerce REST API documentation: https://woocommerce.github.io/woocommerce-rest-api-docs/
- Review WordPress REST API: https://developer.wordpress.org/rest-api/

