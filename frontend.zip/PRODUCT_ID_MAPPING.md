# Product ID Mapping Guide

## Overview

Your cart items use product IDs from your current system (Medusa/Sanity), but WooCommerce needs its own product IDs. You need to map these IDs so orders are created correctly.

## How to Map Product IDs

### Step 1: Identify Your Product IDs

Check what product IDs are in your cart items. They might be:
- Numeric IDs (e.g., `123`)
- String IDs (e.g., `"product-123"`)
- MongoDB-style IDs (e.g., `"_id": "507f1f77bcf86cd799439011"`)

### Step 2: Get WooCommerce Product IDs

1. Log in to WordPress admin: https://zdacomm.com/wp-admin
2. Go to **Products** → **All Products**
3. Click on a product to edit it
4. Look at the URL: `https://zdacomm.com/wp-admin/post.php?post=123&action=edit`
   - The number `123` is the WooCommerce product ID

### Step 3: Update the Mapping

Edit `frontend/src/lib/woocommerce/utils.ts` and update the `PRODUCT_ID_MAP`:

```typescript
const PRODUCT_ID_MAP: Record<string, number> = {
  // Your product ID -> WooCommerce product ID
  "your-product-id-1": 123,  // WooCommerce product ID
  "your-product-id-2": 456,
  "cable-custom-10ft": 789,
  // Add all your products here
};
```

### Step 4: Alternative - Use Metadata

If you prefer, you can add the WooCommerce product ID to your product metadata:

```javascript
{
  id: "your-product-id",
  metadata: {
    woocommerce_product_id: 123,  // WooCommerce will use this
    // ... other metadata
  }
}
```

## Testing

1. Add a product to cart
2. Go to checkout
3. Complete the order
4. Check WooCommerce admin to verify the order was created with correct products

## Troubleshooting

### Product ID is 0

If you see warnings about product ID being 0:
- Check the browser console for the item structure
- Add the mapping to `PRODUCT_ID_MAP`
- Or add `woocommerce_product_id` to product metadata

### Wrong Products in Orders

- Verify your product ID mappings are correct
- Check that WooCommerce product IDs exist
- Ensure products are published in WooCommerce

## Example Mapping

```typescript
const PRODUCT_ID_MAP: Record<string, number> = {
  // Cables
  "cable-sma-10ft": 101,
  "cable-sma-25ft": 102,
  "cable-tnc-10ft": 103,
  
  // Connectors
  "connector-sma-male": 201,
  "connector-sma-female": 202,
  
  // Add all products...
};
```

